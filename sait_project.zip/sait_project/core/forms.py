from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['title', 'price', 'tags']
        widgets = {
            'tags': forms.CheckboxSelectMultiple,
        }
        labels = {
            'title':'Nazvanie',
            'price': 'Tcena'
        }