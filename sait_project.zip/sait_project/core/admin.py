#from  .models import Product, Category, Tag, ProductSpecs
from  .models import Actor, Movie
from django.contrib import admin

# Register your models here.

# @admin.register(Category)
# class CategoryAdmin(admin.ModelAdmin): pass

# @admin.register(Tag)
# class TagAdmin(admin.ModelAdmin): pass

# @admin.register(Product)
# class ProductAdmin(admin.ModelAdmin): 
#     list_display = ('title', 'price', 'categgory','created_at')
#     list_filter = ('categgory', 'tags')
#     filter_horizontal = ('tags',)

# @admin.register(ProductSpecs)
# class SpecAdmin(admin.ModelAdmin): pass

@admin.register(Actor)
class ActorAdmin(admin.ModelAdmin):
    list_display = ('name', 'birth_year', 'country')

@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'year', 'director')
    filter_horizontal = ('actors',)