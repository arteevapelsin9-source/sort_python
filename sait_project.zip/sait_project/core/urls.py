from django.urls import path
from . import views

urlpatterns = [
    # path('index', views.index_view),
    # path('test', views.test_view),
    # path('product/<int:pk>', views.product_detail, name = 'product_name' )
    path('search-actor', views.search_actor, name = 'search_actor')
    path('movie/<int:pk>', views.movie_detail, name = 'movie_detail'),
]