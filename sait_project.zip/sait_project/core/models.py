from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.

# class Category(models.Model):
#     name = models.CharField(max_length=50)
#     def __str__(self): return self.name

# class Tag(models.Model):
#     name = models.CharField(max_length=30)
#     def __str__(self): return self.name

# class ProductSpecs(models.Model):
#     wes = models.FloatField()
#     dimensions = models.CharField(max_length=20, blank = True)

# class Product(models.Model):
#     title = models.CharField(max_length = 150, unique = True)
#     description = models.TextField(blank = True,default = 'No desc')
#     slug = models.SlugField(max_length = 150, unique = True)
#     category = models.CharField(
#         max_length=20,
#         choices=[('e1', 'Electr'), ('b2', 'Books'), ('o3', 'Other')],
#         default='other'
#         )
#     # mnogim towaram sopostavili 1 category 
#     categgory = models.ForeignKey(
#         Category, on_delete=models.SET_NULL, null = True, blank = True,
#         related_name='products'
#     )
    
#     # 1 ������� - 1 �����
#     specs = models.OneToOneField(
#         'ProductSpecs', on_delete=models.CASCADE, null = True, blank=True, related_name = 'product'
#     )

#     # ����� ������� - ����� �����
#     tags = models.ManyToManyField(Tag, related_name='products', blank = True)

#     price = models.DecimalField(max_digits=10, decimal_places=2)
#     stock = models.PositiveIntegerField(default=0)
#     weight = models.FloatField(null = True, blank = True)
#     rating = models.IntegerField(validators = [MinValueValidator(1), MaxValueValidator(10)])
#     published = models.BooleanField(default=False)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated = models.DateTimeField(auto_now=True)
#     release_date = models.DateTimeField(null=True, blank=True)
#     publish_time = models.DateTimeField(null=True, blank=True)
#     website = models.URLField(blank=True)
#     server_ip = models.GenericIPAddressField(protocol='both', null = True, blank= True)

#     class Meta:
#         verbose_name = 'Towar'
#         verbose_name_plural = 'Towari'
#         ordering = ['-created_at']

#     def __str__(self):
#         return self.title


class Actor(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='Aktors Name')
    birth_year = models.IntegerField(null=True, blank=True, verbose_name='Bearth Year')
    country = models.CharField(max_length=50, blank=True, verbose_name='Country')
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = 'Actor'
        verbose_name_plural = 'Actors'

class Movie(models.Model):
    title = models.CharField(max_length=200, verbose_name='Movie Name')
    year = models.IntegerField(verbose_name='Movie Bearth Year')
    director = models.CharField(max_length=100, blank=True, verbose_name='Director of Movie')
    # c���� ������ �� ������ � �������
    actors = models.ManyToManyField(Actor, related_name='movies', verbose_name='Actors')
    
    def __str__(self):
        return f"{self.title} ({self.year})"
    
    class Meta:
        verbose_name = 'Movie'
        verbose_name_plural = 'Movies'
        ordering = ['-year']