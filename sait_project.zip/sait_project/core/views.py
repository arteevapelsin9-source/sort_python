from django.shortcuts import redirect, render, get_object_or_404
#from .models import Product
from django.http import HttpResponse
from .models import Actor, Movie
#from .forms import ProductForm
# def index_view(request):
#     return HttpResponse('<h1>Glavnaya</h1><p>Hello</p>')

# def test_view(request):
#     return HttpResponse('<h1>Testovaya</h1><p>Hello__2</p>')

# def product_detail(request, pk):
#     product = get_object_or_404(Product, pk = pk)
#     return render(request, 'product_detail.html', {'prod_in_template': product}) 

# def add_product(request):
#     if request.method == 'POST':
#         form = ProductForm(request.POST)
#         form.save()
#         return redirect('product_detail')
#     else:
#         form = ProductForm()
#     return render(request, 'core/add_product.html', {'form': form})


def search_actor(request):
    result = None
    actor_name = None
    error = None
    if request.method == 'POST':
        actor_name = request.POST.get('actor_name', '').strip()
        if actor_name:
            try:
                # ���� ����� � �������� ��� ��� ������
                actor = Actor.objects.get(name__icontains=actor_name)
                movies = actor.movies.all().order_by('-year')
                result = {
                    'actor': actor,
                    'movies': movies
                }
            except Actor.DoesNotExist:
                error = f'Actor "{actor_name}" not found'
        else:
            error = 'Write name'
    
    return render(request, 'search_actor.html', {
        'result': result,
        'actor_name': actor_name,
        'error': error
    })   